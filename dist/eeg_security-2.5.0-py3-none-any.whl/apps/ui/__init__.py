"""EEG OSS UI app."""
