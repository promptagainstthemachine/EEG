"""EEG OSS Django apps."""
